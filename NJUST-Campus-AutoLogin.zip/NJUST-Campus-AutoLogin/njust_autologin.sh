#!/bin/bash
set -u
umask 077
LABEL='com.njust.autologin'
APP_DIR="$HOME/.njust-autologin"
SCRIPT_PATH="$APP_DIR/njust_autologin.sh"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
LOG="$HOME/Library/Logs/NJUSTAutoLogin.v5.log"
CURL_LOG="$HOME/Library/Logs/NJUSTAutoLogin.v5.curl.log"
ERR_LOG="$HOME/Library/Logs/NJUSTAutoLogin.v5.error.log"
IFACE='en1'
INTERVAL=10
MIN_RETRY=30
# 若需要 Wi-Fi 完全断开后重新加入网络，在这里填写已保存过的校园 Wi-Fi 名称。
# 如果仍为空，脚本只能完成校园网认证，不能凭空恢复无线关联。
WIFI_SSID=''

exact_login_curl() {
curl -sS -i -v \
  --proxy 'http://127.0.0.1:7890' \
  --connect-timeout 5 \
  --max-time 15 \
  'http://m.njust.edu.cn/api/portal/v1/login' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'Origin: http://m.njust.edu.cn' \
  -H 'Referer: http://m.njust.edu.cn/portal/index.html?v=202011022108' \
  -H 'X-Requested-With: XMLHttpRequest' \
  --data-raw '{"domain":"default","username":"YOUR_USERNAME","password":"YOUR_PASSWORD"}'
}

prepare() { /bin/mkdir -p "$HOME/Library/Logs"; /usr/bin/touch "$LOG" "$CURL_LOG" "$ERR_LOG"; /bin/chmod 600 "$LOG" "$CURL_LOG" "$ERR_LOG"; }
log() { /usr/bin/printf '[%s] [v5 pid=%s] %s\n' "$(/bin/date '+%Y-%m-%dT%H:%M:%S%z')" "$$" "$*" >> "$LOG"; }
net_ip() { /sbin/ipconfig getifaddr "$IFACE" 2>/dev/null || true; }
# 验证公网 TLS 和真实内容，防止校园网重定向页面仅返回 200 时误判联网。
probe() {
  local content
  content=$(/usr/bin/curl -fsS -L --noproxy '*' --interface "$IFACE" --connect-timeout 2 --max-time 4 'https://www.gstatic.com/generate_204' -o /dev/null -w '%{http_code}' 2>/dev/null) || return 1
  [ "$content" = '204' ]
}
proxy_alive() { /usr/bin/nc -G 2 -z 127.0.0.1 7890 >/dev/null 2>&1; }
wifi_state() { /usr/sbin/networksetup -getairportnetwork "$IFACE" 2>&1 | /usr/bin/head -1; }
login() {
  local rc
  log '调用未经修改的原始 curl 登录命令'
  /usr/bin/printf '\n===== %s =====\n' "$(/bin/date '+%Y-%m-%dT%H:%M:%S%z')" >> "$CURL_LOG"
  exact_login_curl >> "$CURL_LOG" 2>&1
  rc=$?
  log "curl 退出码=$rc；完整响应见 $CURL_LOG"
  return "$rc"
}
run() {
  local last=0 now started elapsed remain ip wifi
  prepare
  log "监控开始；接口=$IFACE；周期=${INTERVAL}s；登录最小间隔=${MIN_RETRY}s"
  /usr/bin/caffeinate -i -s -w "$$" >/dev/null 2>&1 &
  while :; do
    started=$(/bin/date +%s)
    ip=$(net_ip)
    if probe; then
      log "公网正常 IPv4=${ip:-无}"
    else
      wifi=$(wifi_state)
      log "公网不通；IPv4=${ip:-无}；Wi-Fi=${wifi}"
      if [ -z "$ip" ] && [ -n "$WIFI_SSID" ]; then
        log "无 IPv4，尝试加入预先配置的 Wi-Fi SSID=$WIFI_SSID"
        /usr/sbin/networksetup -setairportnetwork "$IFACE" "$WIFI_SSID" >> "$ERR_LOG" 2>&1 || log 'Wi-Fi 重新加入失败（可能需权限或密码）'
      fi
      now=$(/bin/date +%s)
      if (( now-last >= MIN_RETRY )); then
        last=$now
        if proxy_alive; then
          login || true
          if probe; then log '登录后公网已恢复'; else log '登录后公网仍不通（详见 curl 响应）'; fi
        else
          log '127.0.0.1:7890 代理未监听，原始命令当前无法连接；等待代理恢复'
        fi
      else
        log '仍在重试冷却期'
      fi
    fi
    elapsed=$(( $(/bin/date +%s) - started ))
    remain=$(( INTERVAL-elapsed ))
    if (( remain > 0 )); then /bin/sleep "$remain"; else /bin/sleep 1; fi
  done
}
install_agent() {
  local uid
  uid=$(/usr/bin/id -u)
  prepare
  /bin/mkdir -p "$APP_DIR" "$HOME/Library/LaunchAgents"
  /bin/chmod 700 "$APP_DIR"
  if [ "$0" != "$SCRIPT_PATH" ]; then /usr/bin/install -m 700 "$0" "$SCRIPT_PATH" || return 1; fi
  /bin/launchctl bootout "gui/$uid/$LABEL" >/dev/null 2>&1 || true
  /bin/cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>$LABEL</string>
<key>ProgramArguments</key><array><string>/bin/bash</string><string>$SCRIPT_PATH</string><string>--run</string></array>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><true/>
<key>StandardOutPath</key><string>$ERR_LOG</string>
<key>StandardErrorPath</key><string>$ERR_LOG</string>
</dict></plist>
EOF
  /bin/chmod 600 "$PLIST"
  /usr/bin/plutil -lint "$PLIST" || return 1
  /bin/launchctl enable "gui/$uid/$LABEL" || true
  /bin/launchctl bootstrap "gui/$uid" "$PLIST" || return 1
  /bin/launchctl kickstart -k "gui/$uid/$LABEL" || return 1
  /bin/sleep 2
  status
  echo '提醒：如果下方进程排查显示其他校园网脚本，它们仍需另外停止。'
  conflicting
}
status() {
  echo '--- launchd ---'
  /bin/launchctl print "gui/$(/usr/bin/id -u)/$LABEL" 2>&1 | /usr/bin/grep -E 'state =|pid =|last exit code|path =|program =' | /usr/bin/head -12
  echo '--- v5 监控日志 ---'
  /usr/bin/tail -n 12 "$LOG" 2>/dev/null || true
  echo '--- v5 curl 日志 ---'
  /usr/bin/tail -n 12 "$CURL_LOG" 2>/dev/null || true
}
conflicting() {
  echo '--- 可能的其他校园网脚本进程（仅展示，不自动终止） ---'
  /bin/ps -axo pid,ppid,command | /usr/bin/grep -Ei 'NJUSTAutoLogin|njust.*auto|portal_io/login' | /usr/bin/grep -v -E 'grep -Ei|--diagnose' || true
  echo '--- 可能的其他 launchd 服务 ---'
  /bin/launchctl list | /usr/bin/grep -Ei 'njust|campus|autologin' || true
}
case "${1:---run}" in
--install) install_agent;;
--run) run;;
--login-once) prepare; login; /usr/bin/tail -n 50 "$CURL_LOG";;
--status) status;;
--diagnose) status; conflicting; echo '--- Wi-Fi ---'; wifi_state; echo '--- IPv4 ---'; net_ip; echo '--- 代理监听 ---'; if proxy_alive; then echo yes; else echo no; fi;;
--uninstall) /bin/launchctl bootout "gui/$(/usr/bin/id -u)/$LABEL" 2>/dev/null || true; /bin/rm -f "$PLIST"; echo '已停用本服务（不影响其他历史服务）';;
*) echo 'Usage: --install | --login-once | --status | --diagnose | --run | --uninstall'; exit 2;;
esac
